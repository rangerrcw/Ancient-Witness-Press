IMPORT-0003 authoritative Grok package
Source folder: artifacts/Quran_Research (working copies hashed here)
Contents are original files, not summaries.
Platform governance (Architecture/Vocab/Schema/Import Spec/Physical Plan) excluded; those live in 00_Governance.
Files: 134
